from Database import Database
from Model import Model

class Usuario(Model):
    def __init__(self, nombre, email):
        super().__init__(table_name="usuarios")
        self.id = None
        self.nombre = nombre
        self.email = email



if __name__ == "__main__":
    # Creamos un objeto Usuario
    nuevo_usuario = Usuario(nombre="Juan Perez", email="juan@example.com")

    # Creamos la tabla en la base de datos (solo necesario una vez)
    nuevo_usuario.createTable()

    # Insertamos el nuevo usuario en la base de datos
    nuevo_usuario.save()
