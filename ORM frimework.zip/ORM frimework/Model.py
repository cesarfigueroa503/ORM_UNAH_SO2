from Database import Database

class Model:
    def __init__(self, table_name=None):
        self.db = Database(dbname="pureba001", user="postgres", password="root")
        self.tableName = table_name
        self.fields = []

    def createTable(self):
        self.tableName = self.get_class_name()
        self.fields = self.get_fields()
        if self.tableName is None or len(self.fields) == 0:
            raise ValueError("Nombre de tabla o campos no definidos en la clase hija.")

        try:
            self.db.connect()
            cursor = self.db._connection.cursor()

            field_definitions = ", ".join(f"{field} VARCHAR(255)" for field in self.fields)
            query = f"CREATE TABLE IF NOT EXISTS {self.tableName} (id_base SERIAL PRIMARY KEY, {field_definitions})"
            
            cursor.execute(query)

            cursor.close()
            self.db.disconnect()
            print(f"Tabla {self.tableName} creada exitosamente.")

        except Exception as e:
            print("Error al crear la tabla:", e)

    def save(self):
        if self.tableName is None or len(self.fields) == 0:
            raise ValueError("Nombre de tabla o campos no definidos en la clase hija.")

        try:
            self.db.connect()
            cursor = self.db.connection.cursor()

            field_names = ", ".join(self.fields)
            placeholders = ", ".join("%s" for _ in self.fields)
            values = [getattr(self, field) for field in self.fields]

            query = f"INSERT INTO {self.tableName} ({field_names}) VALUES ({placeholders})"
            cursor.execute(query, values)

            cursor.close()
            self.db.disconnect()
            print("Registro insertado correctamente.")

        except Exception as e:
            print("Error al insertar el registro:", e)

    def update(self):
        raise NotImplementedError

    def delete(self):
        raise NotImplementedError
    
    def getById(self, model_id):
        raise NotImplementedError

    def findAll(self):
        raise NotImplementedError

    def get_fields(self):
        if self.fields:
            return self.fields
        else:
            return [field for field in self.__dict__ if not field.startswith("_")]

    def get_class_name(self):
        return self.__class__.__name__
